import express, { json } from "express";
import morgan from "morgan";
import { localRouter } from "./routes/local.routes.js";
//import { archivoRouter } from "./routes/archivo.routes.js";

const app = express();

app.use(morgan("dev"));
app.use(json());

// defino mis rutas
//app.use(authRouter);
//app.use(tipoProductoRouter);
app.use(localRouter);
//app.use(archivoRouter);
// fin de la definicion

const PORT = process.env.PORT ?? 4000;

app.listen(PORT, () => {
  console.log(`Servidor corriendo exitosamente en el puerto ${PORT}`);
});
