import { localDto } from "../dto/local.dto.js";
import { LocalService } from "../services/local.service.js";

export async function crear(req, res) {
  // crear el archivo local.dto.js en los dtos/request y agregar las validaciones que vean pertinentes
  try {
    const data = localDto(req.body);

    const resultado = await LocalService.crearLocal(data);

    return res.status(201).json(resultado);
  } catch (error) {
    return res.status(400).json({
      message: error.message,
    });
  }
}
