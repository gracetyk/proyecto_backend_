
const res = require('express/lib/response')
const pool = require('../db')

const getAllTask = async (req, res) => {

    try {
        const alltask = await pool.query("select * from public.categoria")
        console.log(getAllTask)
        res.json(alltask.rows)
    } catch (error) {
        res.json({ error: error.message })
    }
};

const getTask = async (req, res) => {
    try {
        const { id } = req.params
        const result = await pool.query('select * from public.categoria where categoria_id =$1', [id])

        if (result.rows.length === 0) return res.status(404).json(
            {
                message: "task not found"
            })

        return res.json(result.rows[0]);
    } catch (error) {
        res.json({ message: error.message })
    }
};

const createTask = async (req, res) => {
    const { title, description } = req.body

    try {
        const result = await pool.query("insert into public.categoria (nom_categ,desc_categ) values ($1,$2) RETURNING *", [
            title,
            description
        ]);
        console.log(result);
        //res.send('creating a task ');
        res.json(result.rows[0])
    } catch (error) {
        //console.log(error.message)
        res.json({ error: error.message })
    }
};

const deleteTask = async (req, res) => {

    try {
        const { id } = req.params
        const result = await pool.query('delete from public.categoria where categoria_id= $1', [id])

        if (result.rowCount === 0) return res.status(404).json({
            message: "Object not found"
        });
        return res.sendStatus(204);
        res.send('Object deleted ');

    } catch (error) {
        res.json({ message: error.message })
    }

    //console.log(result)
    //res.send('deleting a task ');
}

const updateTask = (req, res) => {
    res.send('updating a task ');
}

module.exports = {
    getAllTask,
    getTask,
    createTask,
    deleteTask,
    updateTask
}